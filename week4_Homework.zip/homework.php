<!DOCTYPE HTML>
<html lang="zh-TW">
<head>
<meta charset="utf-8">
</head>
<body>
<form action="check.php" method="post">
Your ID:<input type="text" name="id"><br>
Your password:<input type="password" name="pwd"><br>
<input type="submit"><input type="reset">
</form>
</body>
</html>