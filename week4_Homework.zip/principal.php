<?php
session_start();
if($_SESSION["P_login"]!="Yes"){
    header("Location:error.php");
}

?>
<html lang="zh-TW">
<head>
<meta charset="utf-8">
</head>
<body>
歡迎校長登入!<br>
<a href="teacher.php">點此</a>視察老師網頁<br>
<a href="logout.php">Logout</a>
</body>
</html>