<html lang="zh-TW">
<head>
<meta charset="utf-8">
</head>
<body>
非法登入網頁!將在2秒鐘後跳轉回登入頁面
<?php
header("Refresh:2;url=homework.php");
?>
</body>
</html>