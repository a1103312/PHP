<?php
session_start();
if(($_SESSION["T_login"]!="Yes")&&($_SESSION["P_login"]!="Yes")){
    header("Location:error.php");
}

?>
<html lang="zh-TW">
<head>
<meta charset="utf-8">
</head>
<body>
歡迎校長或老師登入!<br>
若您是老師，可<a href="student.php">點此</a>視察學生網頁<br>
<a href="logout.php">Logout</a>
</body>
</html>