<?php
session_start();
if(($_SESSION["T_login"]!="Yes")&&($_SESSION["S_login"]!="Yes")){
    header("Location:error.php");
}

?>
<html lang="zh-TW">
<head>
<meta charset="utf-8">
</head>
<body>
歡迎老師或學生登入!<br>
<a href="logout.php">Logout</a>
</body>
</html>