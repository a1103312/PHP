<?php
session_start();

$id=$_POST["id"];
$pwd=$_POST["pwd"];

$principalID="Chen";
$principalPWD="3333";

$teacherID="Derrick";
$teacherPWD="2222";

$studentID="Allan";
$studentPWD="1111";

$_SESSION["P_login"]="initial value";
$_SESSION["T_login"]="initial value";
$_SESSION["S_login"]="initial value";

if(($id==$principalID)&&($pwd==$principalPWD)){
    $_SESSION["P_login"]="Yes";
    header("Location:principal.php");
}elseif(($id==$teacherID)&&($pwd==$teacherPWD)){
    $_SESSION["T_login"]="Yes";
    header("Location:teacher.php");
}elseif(($id==$studentID)&&($pwd==$studentPWD)){
    $_SESSION["S_login"]="Yes";
    header("Location:student.php");
}else{
    $_SESSION["login"]="No";
    header("Location:fail.php");
}
?>